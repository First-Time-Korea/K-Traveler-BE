-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: firsttimeinkorea
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `gugun`
--

DROP TABLE IF EXISTS `gugun`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gugun` (
  `gugun_code` int NOT NULL,
  `gugun_name` varchar(30) DEFAULT NULL,
  `sido_code` int NOT NULL,
  PRIMARY KEY (`gugun_code`,`sido_code`),
  KEY `gugun_to_sido_sido_code_fk_idx` (`sido_code`),
  CONSTRAINT `gugun_to_sido_sido_code_fk` FOREIGN KEY (`sido_code`) REFERENCES `sido` (`sido_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gugun`
--

LOCK TABLES `gugun` WRITE;
/*!40000 ALTER TABLE `gugun` DISABLE KEYS */;
INSERT INTO `gugun` VALUES (1,'Gangnam-gu',1),(1,'Ganghwa-gun',2),(1,'Daedeok-gu',3),(1,'Nam-gu',4),(1,'Gwangsan-gu',5),(1,'Gangseo-gu',6),(1,'Jung-gu',7),(1,'Sejong',8),(1,'Gapyeong-gun',31),(1,'Gangneung-si',32),(1,'Goesan-gun',33),(1,'Gongju-si',34),(1,'Gyeongsan-si',35),(1,'Geoje-si',36),(1,'Gochang-gun',37),(1,'Gangjin-gun',38),(2,'Gangdong-gu',1),(2,'Gyeyang-gu',2),(2,'Dong-gu',3),(2,'Dalseo-gu',4),(2,'Nam-gu',5),(2,'Geumjeong-gu',6),(2,'Nam-gu',7),(2,'Goyang-si',31),(2,'Goseong-gun',32),(2,'Danyang-gun',33),(2,'Geumsan-gun',34),(2,'Gyeongju-si',35),(2,'Geochang-gun',36),(2,'Gunsan-si',37),(2,'Goheung-gun',38),(3,'Gangbuk-gu',1),(3,'Michuhol-gu',2),(3,'Seo-gu',3),(3,'Dalseong-gun',4),(3,'Dong-gu',5),(3,'Gijang-gun',6),(3,'Dong-gu',7),(3,'Gwacheon-si',31),(3,'Donghae-si',32),(3,'Boeun-gun',33),(3,'Nonsan-si',34),(3,'Goryeong-gun',35),(3,'Goseong-gun',36),(3,'Gimje-si',37),(3,'Gokseong-gun',38),(3,'Seogwipo-si',39),(4,'Gangseo-gu',1),(4,'Namdong-gu',2),(4,'Yuseong-gu',3),(4,'Dong-gu',4),(4,'Buk-gu',5),(4,'Nam-gu',6),(4,'Buk-gu',7),(4,'Gwangmyeong-si',31),(4,'Samcheok-si',32),(4,'Yeongdong-gun',33),(4,'Dangjin-si',34),(4,'Gumi-si',35),(4,'Gimhae-si',36),(4,'Namwon-si',37),(4,'Gwangyang-si',38),(4,'Jeju-si',39),(5,'Gwanak-gu',1),(5,'Dong-gu',2),(5,'Jung-gu',3),(5,'Buk-gu',4),(5,'Seo-gu',5),(5,'Dong-gu',6),(5,'Ulju-gun',7),(5,'Gwangju-si',31),(5,'Sokcho-si',32),(5,'Okcheon-gun',33),(5,'Boryeong-si',34),(5,'Gimcheon-si',35),(5,'Namhae-gun',36),(5,'Muju-gun',37),(5,'Gurye-gun',38),(6,'Gwangjin-gu',1),(6,'Bupyeong-gu',2),(6,'Seo-gu',4),(6,'Dongnae-gu',6),(6,'Guri-si',31),(6,'Yanggu-gun',32),(6,'Eumseong-gun',33),(6,'Buyeo-gun',34),(6,'Mungyeong-si',35),(6,'Miryang-si',36),(6,'Buan-gun',37),(6,'Naju-si',38),(7,'Guro-gu',1),(7,'Seo-gu',2),(7,'Suseong-gu',4),(7,'Busanjin-gu',6),(7,'Gunpo-si',31),(7,'Yangyang-gun',32),(7,'Jecheon-si',33),(7,'Seosan-si',34),(7,'Bonghwa-gun',35),(7,'Sacheon-si',36),(7,'Sunchang-gun',37),(7,'Damyang-gun',38),(8,'Geumcheon-gu',1),(8,'Yeonsu-gu',2),(8,'Jung-gu',4),(8,'Buk-gu',6),(8,'Gimpo-si',31),(8,'Yeongwol-gun',32),(8,'Jincheon-gun',33),(8,'Seocheon-gun',34),(8,'Sangju-si',35),(8,'Sancheong-gun',36),(8,'Wanju-gun',37),(8,'Mokpo-si',38),(9,'Nowon-gu',1),(9,'Ongjin-gun',2),(9,'Gunwi-gun',4),(9,'Sasang-gu',6),(9,'Namyangju-si',31),(9,'Wonju-si',32),(9,'Cheongju-si',33),(9,'Asan-si',34),(9,'Seongju-gun',35),(9,'Yangsan-si',36),(9,'Iksan-si',37),(9,'Muan-gun',38),(10,'Dobong-gu',1),(10,'Jung-gu',2),(10,'Saha-gu',6),(10,'Dongducheon-si',31),(10,'Inje-gun',32),(10,'Chungju-si',33),(10,'Yesan-gun',34),(10,'Andong-si',35),(10,'Uiryeong-gun',36),(10,'Imsil-gun',37),(10,'Boseong-gun',38),(11,'Dongdaemun-gu',1),(11,'Seo-gu',6),(11,'Bucheon-si',31),(11,'Jeongseon-gun',32),(11,'Jeungpyeong-gun',33),(11,'Cheonan-si',34),(11,'Yeongdeok-gun',35),(11,'Jinju-si',36),(11,'Jangsu-gun',37),(11,'Suncheon-si',38),(12,'Dongjak-gu',1),(12,'Suyeong-gu',6),(12,'Seongnam-si',31),(12,'Cheorwon-gun',32),(12,'Cheongyang-gun',34),(12,'Yeongyang-gun',35),(12,'Changnyeong-gun',36),(12,'Jeonju-si',37),(12,'Sinan-gun',38),(13,'Mapo-gu',1),(13,'Yeonje-gu',6),(13,'Suwon-si',31),(13,'Chuncheon-si',32),(13,'Taean-gun',34),(13,'Yeongju-si',35),(13,'Changwon-si',36),(13,'Jeongeup-si',37),(13,'Yeosu-si',38),(14,'Seodaemun-gu',1),(14,'Yeongdo-gu',6),(14,'Siheung-si',31),(14,'Taebaek-si',32),(14,'Hongseong-gun',34),(14,'Yeongcheon-si',35),(14,'Tongyeong-si',36),(14,'Jinan-gun',37),(14,'Yeonggwang-gun',38),(15,'Seocho-gu',1),(15,'Jung-gu',6),(15,'Ansan-si',31),(15,'Pyeongchang-gun',32),(15,'Yecheon-gun',35),(15,'Hadong-gun',36),(15,'Yeongam-gun',38),(16,'Seongdong-gu',1),(16,'Haeundae-gu',6),(16,'Anseong-si',31),(16,'Hongcheon-gun',32),(16,'Ulleung-gun',35),(16,'Haman-gun',36),(16,'Wando-gun',38),(17,'Seongbuk-gu',1),(17,'Anyang-si',31),(17,'Hwacheon-gun',32),(17,'Uljin-gun',35),(17,'Hamyang-gun',36),(17,'Jangseong-gun',38),(18,'Songpa-gu',1),(18,'Yangju-si',31),(18,'Hoengseong-gun',32),(18,'Uiseong-gun',35),(18,'Hapcheon-gun',36),(18,'Jangheung-gun',38),(19,'Yangcheon-gu',1),(19,'Yangpyeong-gun',31),(19,'Cheongdo-gun',35),(19,'Jindo-gun',38),(20,'Yeongdeungpo-gu',1),(20,'Yeoju-si',31),(20,'Cheongsong-gun',35),(20,'Hampyeong-gun',38),(21,'Yongsan-gu',1),(21,'Yeoncheon-gun',31),(21,'Chilgok-gun',35),(21,'Haenam-gun',38),(22,'Eunpyeong-gu',1),(22,'Osan-si',31),(22,'Pohang-si',35),(22,'Hwasun-gun',38),(23,'Jongno-gu',1),(23,'Yongin-si',31),(24,'Jung-gu',1),(24,'Uiwang-si',31),(25,'Jungnang-gu',1),(25,'Uijeongbu-si',31),(26,'Icheon-si',31),(27,'Paju-si',31),(28,'Pyeongtaek-si',31),(29,'Pocheon-si',31),(30,'Hanam-si',31),(31,'Hwaseong-si',31);
/*!40000 ALTER TABLE `gugun` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-15 20:25:09
