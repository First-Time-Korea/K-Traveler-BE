-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: firsttimeinkorea
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `plan`
--

DROP TABLE IF EXISTS `plan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `member_id` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `created_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `modified_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `member_id` (`member_id`),
  CONSTRAINT `plan_to_member_id_fk` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plan`
--

LOCK TABLES `plan` WRITE;
/*!40000 ALTER TABLE `plan` DISABLE KEYS */;
INSERT INTO `plan` VALUES (7,'qwer','test title','2024-06-28 12:51:10','2024-06-28 12:51:10'),(10,'qwer','test title','2024-06-28 12:56:32','2024-06-28 12:56:32'),(11,'qwer','test title','2024-06-28 12:56:55','2024-06-28 12:56:55'),(12,'qwer','test title','2024-06-28 12:58:07','2024-06-28 12:58:07'),(13,'qwer','test title','2024-06-28 12:58:09','2024-06-28 12:58:09'),(14,'qwer','test title','2024-06-28 12:58:10','2024-06-28 12:58:10'),(15,'qwer','test title','2024-06-28 12:58:11','2024-06-28 12:58:11'),(16,'qwer','test title','2024-06-28 12:58:11','2024-06-28 12:58:11'),(17,'qwer','test title','2024-06-28 12:58:12','2024-06-28 12:58:12'),(18,'qwer','test title','2024-06-28 12:58:13','2024-06-28 12:58:13'),(19,'qwer','test title','2024-06-28 12:58:17','2024-06-28 12:58:17'),(20,'qwer','test title','2024-06-28 12:58:18','2024-06-28 12:58:18'),(21,'qwer','test title','2024-06-28 12:58:18','2024-06-28 12:58:18'),(22,'qwer','test title','2024-06-28 12:58:19','2024-06-28 12:58:19'),(23,'qwer','test title','2024-06-28 12:58:20','2024-06-28 12:58:20'),(24,'qwer','test title','2024-06-28 12:58:20','2024-06-28 12:58:20'),(25,'qwer','test title','2024-06-28 12:58:21','2024-06-28 12:58:21'),(26,'qwer','test title','2024-06-28 12:58:22','2024-06-28 12:58:22'),(27,'qwer','test title','2024-06-28 12:58:22','2024-06-28 12:58:22'),(28,'qwer','test title','2024-06-28 12:58:23','2024-06-28 12:58:23'),(29,'qwer','test title','2024-06-28 12:58:24','2024-06-28 12:58:24'),(30,'qwer','test title','2024-06-28 12:58:24','2024-06-28 12:58:24'),(31,'qwer','test title','2024-06-28 12:58:25','2024-06-28 12:58:25'),(32,'qwer','test title','2024-06-28 12:58:26','2024-06-28 12:58:26'),(33,'qwer','test title','2024-06-28 12:58:27','2024-06-28 12:58:27'),(34,'qwer','test title','2024-06-28 13:03:23','2024-06-28 13:03:23'),(35,'qwer','test title','2024-06-28 13:03:28','2024-06-28 13:03:28'),(36,'qwer','test title','2024-06-28 13:04:19','2024-06-28 13:04:19'),(37,'qwer','test title','2024-06-28 13:06:05','2024-06-28 13:06:05'),(38,'qwer','test title','2024-06-28 13:08:18','2024-06-28 13:08:18'),(39,'qwer','test title','2024-06-28 13:08:25','2024-06-28 13:08:25'),(40,'qwer','test title','2024-06-28 13:08:26','2024-06-28 13:08:26'),(41,'qwer','test title','2024-06-28 13:09:28','2024-06-28 13:09:28'),(42,'qwer','test title','2024-06-28 13:09:29','2024-06-28 13:09:29'),(43,'qwer','test title','2024-06-28 13:09:30','2024-06-28 13:09:30'),(44,'qwer','test title','2024-06-28 13:09:31','2024-06-28 13:09:31'),(45,'qwer','test title','2024-06-28 13:09:32','2024-06-28 13:09:32'),(46,'qwer','test title','2024-06-28 13:09:33','2024-06-28 13:09:33'),(47,'qwer','test title','2024-06-28 13:09:33','2024-06-28 13:09:33'),(48,'qwer','test title','2024-06-28 13:09:34','2024-06-28 13:09:34'),(49,'qwer','test title','2024-06-28 13:09:35','2024-06-28 13:09:35'),(50,'qwer','test title','2024-06-28 13:09:35','2024-06-28 13:09:35'),(51,'qwer','test title','2024-06-28 13:09:36','2024-06-28 13:09:36'),(52,'qwer','test title','2024-06-28 13:09:37','2024-06-28 13:09:37'),(53,'qwer','test title','2024-06-28 13:09:41','2024-06-28 13:09:41'),(54,'qwer','test title','2024-06-28 13:09:41','2024-06-28 13:09:41'),(55,'qwer','test title','2024-06-28 13:09:42','2024-06-28 13:09:42'),(56,'qwer','test title','2024-06-28 13:09:42','2024-06-28 13:09:42'),(57,'qwer','test title','2024-06-28 13:09:43','2024-06-28 13:09:43'),(58,'qwer','test title','2024-06-28 13:09:44','2024-06-28 13:09:44'),(59,'qwer','test title','2024-06-28 13:09:44','2024-06-28 13:09:44'),(60,'qwer','test title','2024-06-28 13:09:45','2024-06-28 13:09:45'),(61,'qwer','test title','2024-06-28 13:09:45','2024-06-28 13:09:45'),(62,'qwer','test title','2024-06-28 13:09:46','2024-06-28 13:09:46'),(63,'qwer','test title','2024-06-28 13:10:55','2024-06-28 13:10:55'),(64,'qwer','test title','2024-06-28 13:12:56','2024-06-28 13:12:56'),(65,'qwer','test title','2024-06-28 13:12:58','2024-06-28 13:12:58'),(66,'qwer','test title','2024-06-28 13:12:59','2024-06-28 13:12:59'),(67,'qwer','test title','2024-06-28 13:13:00','2024-06-28 13:13:00'),(68,'qwer','test title','2024-06-28 13:13:00','2024-06-28 13:13:00'),(69,'qwer','test title','2024-06-28 13:13:06','2024-06-28 13:13:06'),(70,'qwer','test title','2024-06-28 13:13:07','2024-06-28 13:13:07'),(71,'qwer','test title','2024-06-28 13:13:08','2024-06-28 13:13:08'),(72,'qwer','test title','2024-06-28 13:13:08','2024-06-28 13:13:08'),(73,'qwer','test title','2024-06-28 13:13:09','2024-06-28 13:13:09'),(74,'qwer','test title','2024-06-28 13:13:10','2024-06-28 13:13:10'),(75,'qwer','test title','2024-06-28 13:13:10','2024-06-28 13:13:10'),(76,'qwer','test title','2024-06-28 13:13:12','2024-06-28 13:13:12'),(77,'qwer','test title','2024-06-28 13:17:25','2024-06-28 13:17:25'),(78,'qwer','test title','2024-06-28 13:17:26','2024-06-28 13:17:26'),(79,'qwer','test title','2024-06-28 13:17:26','2024-06-28 13:17:26'),(80,'qwer','test title','2024-06-28 13:19:20','2024-06-28 13:19:20'),(81,'qwer','test title','2024-06-28 13:19:38','2024-06-28 13:19:38'),(82,'qwer','test title','2024-06-28 13:20:17','2024-06-28 13:20:17'),(83,'qwer','test title','2024-06-28 15:15:11','2024-06-28 15:15:11'),(84,'qwer','test title','2024-06-28 15:15:14','2024-06-28 15:15:14'),(85,'qwer','test title','2024-06-28 15:16:04','2024-06-28 15:16:04'),(86,'qwer','test title','2024-06-28 15:16:06','2024-06-28 15:16:06'),(87,'qwer','test title','2024-06-28 15:16:11','2024-06-28 15:16:11'),(88,'qwer','test title','2024-07-02 21:10:00','2024-07-02 21:10:00'),(89,'qwer','test title','2024-07-02 21:10:03','2024-07-02 21:10:03'),(90,'qwer','test title','2024-07-02 21:10:36','2024-07-02 21:10:36'),(91,'qwer','test title','2024-07-02 21:10:41','2024-07-02 21:10:41'),(92,'qwer','test title','2024-07-02 21:11:53','2024-07-02 21:11:53'),(93,'qwer','test title','2024-07-02 21:11:57','2024-07-02 21:11:57'),(94,'qwer','test title','2024-07-02 21:11:58','2024-07-02 21:11:58'),(95,'qwer','test title','2024-07-02 21:12:18','2024-07-02 21:12:18'),(96,'qwer','test title','2024-07-02 21:12:40','2024-07-02 21:12:40');
/*!40000 ALTER TABLE `plan` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-15 20:25:10
