-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: firsttimeinkorea
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `category_code` varchar(5) NOT NULL,
  `category_name` varchar(100) DEFAULT NULL,
  `theme_code` varchar(3) NOT NULL,
  PRIMARY KEY (`category_code`,`theme_code`),
  KEY `category_to_theme_theme_code_fk_idx` (`theme_code`),
  CONSTRAINT `category_to_theme_category_code_fk` FOREIGN KEY (`theme_code`) REFERENCES `theme` (`theme_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES ('A01','Korean Restaurant','A'),('A02','Western Restaurant','A'),('A03','Japanese Restaurant','A'),('A04','Chinese Restaurant','A'),('A05','Unique Restaurant','A'),('A06','Bar Cafe','A'),('A07','Club','A'),('B01','Bookstore','B'),('B02','Day Market','B'),('B03','Traditional Market','B'),('B04','Department Store','B'),('B05','Duty Free Shop','B'),('B06','Discount Shop','B'),('B07','Shop Boutique Outlet Mall','B'),('B08','Craft Workshop','B'),('B09','Specialty Shop','B'),('B10','Tax Refund Shop','B'),('C01','Palace','C'),('C02','Fortress','C'),('C03','Gate','C'),('C04','Old House','C'),('C05','Birthplace','C'),('C06','Folk Village','C'),('C07','Historic Site','C'),('C08','Temple','C'),('C09','Holy Site','C'),('C10','Security Peace Site','C'),('C11','Village Experience','C'),('C12','Traditional Experience','C'),('C13','Temple Stay','C'),('C14','Museum','C'),('C15','Memorial Hall','C'),('C16','Exhibition Hall','C'),('C17','Cultural Training Center','C'),('C18','Language Institute','C'),('C19','Special Festival','C'),('C20','Traditional Performance','C'),('C21','Hanok Stay','C'),('D01','National Park','D'),('D02','Provincial Park','D'),('D03','County Park','D'),('D04','Mountain','D'),('D05','Eco Tourism Site','D'),('D06','Recreational Forest','D'),('D07','Botanical Garden','D'),('D08','Waterfall','D'),('D09','Valley','D'),('D10','Mineral Spring','D'),('D11','Coastal Attraction','D'),('D12','Beach','D'),('D13','Island','D'),('D14','Port Harbor','D'),('D15','Lighthouse','D'),('D16','Lake','D'),('D17','River','D'),('D18','Cave','D'),('D19','Rare Animal Plant','D'),('D20','Rock','D'),('D21','Health Tour','D'),('E01','Drama','E'),('E02','Movie','E'),('E03','Entertainment','E'),('E04','Artist','E'),('F01','Hot Spring Spa','F'),('F02','Dry Sauna','F'),('F03','Theme Park','F'),('F04','Park','F'),('F05','Cruise Submarine','F'),('F06','Library','F'),('F07','Movie Theater','F'),('F08','Regular Festival','F'),('G01','Water Leisure Sport','G'),('G02','Sky Leisure Sport','G'),('G03','Training Facility','G'),('G04','Stadium','G'),('G05','Inline Skate','G'),('G06','Bicycle Hike','G'),('G07','Go Kart','G'),('G08','Golf','G'),('G09','Horse Race','G'),('G10','Bicycle Race','G'),('G11','Casino','G'),('G12','Horse Ride','G'),('G13','Skiing Snowboarding','G'),('G14','Ice Skate','G'),('G15','Sledding','G'),('G16','Hunting Ground','G'),('G17','Shooting Range','G'),('G18','Camp','G'),('G19','Rock Climb','G'),('G20','Survival Game','G'),('G21','All Terrain Vehicle','G'),('G22','Mountain Bike','G'),('G23','Off Road Vehicle','G'),('G24','Bungee Jump','G'),('G25','Ski Snowboard Rental','G'),('G26','Trek','G'),('G27','Wind Surfing Jet Ski','G'),('G28','Kayak Canoe','G'),('G29','Yacht','G'),('G30','Snorkeling Scuba Diving','G'),('G31','Freshwater Fishing','G'),('G32','Sea Fishing','G'),('G33','Swim','G'),('G34','Raft','G'),('G35','Sky Dive','G'),('G36','Ultralight Flight','G'),('G37','Hang Gliding Paragliding','G'),('G38','Hot Air Balloon','G'),('G39','Other Leisure Sport','G'),('H01','Unique Experience','H'),('H02','Cultural District','H'),('H03','Power Plant','H'),('H04','Food Beverage','H'),('H05','Industrial Tourist','H'),('H06','Electronic Semiconductor','H'),('H07','Automobile','H'),('H08','Bridge','H'),('H09','Monument Observatory','H'),('H10','Fountain','H'),('H11','Statue','H'),('H12','Tunnel','H'),('H13','Building','H'),('H14','Convention Center','H'),('H15','Art Museum Gallery','H'),('H16','Performance Hall','H'),('H17','Korean Cultural Center','H'),('H18','Foreign Cultural Center','H'),('H19','Play','H'),('H20','Musical','H'),('H21','Opera','H'),('H22','Exhibition','H'),('H23','Exposition','H'),('H24','Dance','H'),('H25','Classical Music Concert','H'),('H26','Popular Music Concert','H'),('H27','Movie','H'),('H28','Other Event','H');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-15 20:25:09
