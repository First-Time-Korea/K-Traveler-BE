-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: firsttimeinkorea
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `plan_file`
--

DROP TABLE IF EXISTS `plan_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plan_file` (
  `id` int NOT NULL AUTO_INCREMENT,
  `plan_id` int NOT NULL,
  `save_folder` varchar(45) NOT NULL,
  `origin_file` varchar(50) NOT NULL,
  `save_file` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `plan_id` (`plan_id`),
  CONSTRAINT `plan_file_to_plan_plan_id_fk` FOREIGN KEY (`plan_id`) REFERENCES `plan` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plan_file`
--

LOCK TABLES `plan_file` WRITE;
/*!40000 ALTER TABLE `plan_file` DISABLE KEYS */;
INSERT INTO `plan_file` VALUES (1,7,'240628','요리왕비룡4.jpg','892f0aa0-ae32-4428-8c43-5fe8682ee4be.jpg'),(2,11,'240628','요리왕비룡4.jpg','39c1231d-2cb7-4fb3-ae45-26ef5dbb53ad.jpg'),(3,12,'240628','요리왕비룡4.jpg','52d904cd-8574-4065-b6f2-dfd7f1d570c5.jpg'),(4,13,'240628','요리왕비룡4.jpg','b37b60aa-4f68-475f-bb44-dfb8ce5b7dfd.jpg'),(5,14,'240628','요리왕비룡4.jpg','285a2f98-9f9f-4f9e-a476-89e9fa48bc1d.jpg'),(6,15,'240628','요리왕비룡4.jpg','6bce1abb-8e4d-4a62-9d0c-f08d30e59503.jpg'),(7,16,'240628','요리왕비룡4.jpg','52ce25b6-1227-484a-8e76-c07c8429f519.jpg'),(8,17,'240628','요리왕비룡4.jpg','e372c317-6635-4055-95d8-74750f4827ee.jpg'),(9,18,'240628','요리왕비룡4.jpg','1f52f106-d682-48f0-868d-67c1205f079b.jpg'),(10,38,'240628','레서판다.jpg','999ea43e-3394-40bc-a450-503335053d1e.jpg'),(11,39,'240628','레서판다.jpg','8044c750-799e-4e8b-b0d7-ad9fd25e9cc0.jpg'),(12,40,'240628','레서판다.jpg','6a4ba670-80c8-4d0d-9536-b8cda43919dd.jpg'),(13,41,'240628','레서판다.jpg','3f9c1a7c-e51c-4555-b8bb-6e6d474f2057.jpg'),(14,42,'240628','레서판다.jpg','72ffe946-34d9-4620-a987-4f7aea3da286.jpg'),(15,43,'240628','레서판다.jpg','b2eb0700-eee3-4b2c-a7df-0712da210a79.jpg'),(16,44,'240628','레서판다.jpg','99430b5a-468f-44a7-b5ce-b9ad941c2ec8.jpg'),(17,45,'240628','레서판다.jpg','eefa0d0f-9078-4d35-b575-4c4b0f3644a2.jpg'),(18,46,'240628','레서판다.jpg','fcda7a13-68eb-47c6-946e-51c2a4b44df4.jpg'),(19,47,'240628','레서판다.jpg','78a2157e-1806-4fa7-a2bf-3c49f022b233.jpg'),(20,48,'240628','레서판다.jpg','41450fdb-c668-4f62-bbe3-0e3aaf8f2012.jpg'),(21,49,'240628','레서판다.jpg','cb6f1a30-2d05-4c0d-8c5c-0cc2822b0353.jpg'),(22,50,'240628','레서판다.jpg','1d425f42-f946-4ca1-bcbe-801465df9210.jpg'),(23,51,'240628','레서판다.jpg','7b2440cd-2137-4a2f-991f-db7490f1f517.jpg'),(24,52,'240628','레서판다.jpg','8942ad44-e4da-4b05-894d-8f850ac6c7df.jpg'),(25,53,'240628','레서판다.jpg','783c5b01-f2d4-4648-b631-ab477ffb91af.jpg'),(26,54,'240628','레서판다.jpg','e2befa61-0bae-4172-ae4d-a092250cfca2.jpg'),(27,55,'240628','레서판다.jpg','5f3dd832-54b0-4584-8889-4d58346f7697.jpg'),(28,56,'240628','레서판다.jpg','ff01323c-31b2-448f-82cc-d5a4f242b7de.jpg'),(29,57,'240628','레서판다.jpg','0e605376-5824-4587-96b7-5f5fa2ec8f6b.jpg'),(30,58,'240628','레서판다.jpg','3eb269c9-4ba1-408d-aae1-c1d80770638b.jpg'),(31,59,'240628','레서판다.jpg','2a9968e4-0034-40a3-966b-d3cb49f7ea6c.jpg'),(32,60,'240628','레서판다.jpg','0d7acb35-a45a-4670-b930-a76b3a6c1e4d.jpg'),(33,61,'240628','레서판다.jpg','80698969-abc6-45ac-b402-c9d88d54053c.jpg'),(34,62,'240628','레서판다.jpg','a298c684-ca38-4855-9fba-e718c319a492.jpg'),(35,63,'240628','레서판다.jpg','4c073fd9-ebab-4c33-a721-0aae7f6af68c.jpg'),(36,64,'240628','강아지.jpg','d11edbf6-a502-4f3f-9a95-09a8d7afa917.jpg'),(37,65,'240628','강아지.jpg','a1e476e1-b53b-4a4d-87cf-7cdee6eb5e26.jpg'),(38,66,'240628','강아지.jpg','a5fea75f-e1d5-4a94-ba8e-cf087caf202a.jpg'),(39,67,'240628','강아지.jpg','068fd8d1-82ac-4470-8253-ab7603bd983f.jpg'),(40,68,'240628','강아지.jpg','afaf1325-a672-439a-8d83-cb19ea986aa3.jpg'),(41,69,'240628','강아지.jpg','bdc4ecde-2550-454e-ad64-28636c69e457.jpg'),(42,70,'240628','강아지.jpg','be6a911a-5b45-4315-8ec5-b775a03da15d.jpg'),(43,71,'240628','강아지.jpg','c51efdbf-834a-46d3-b12a-847cc2c16487.jpg'),(44,72,'240628','강아지.jpg','f41d8c65-06a8-4b51-9c41-779d17c913dd.jpg'),(45,73,'240628','강아지.jpg','d6908e37-4d87-45de-8fc6-b9abf91b278f.jpg'),(46,74,'240628','강아지.jpg','cf7a3085-a18e-427b-9526-5e663ceb6128.jpg'),(47,75,'240628','강아지.jpg','b51667c9-e552-4fcb-97ea-41844b5a4f14.jpg'),(48,76,'240628','강아지.jpg','d9335086-d108-45a5-88b1-63f445937675.jpg'),(49,77,'240628','강아지.jpg','cbf8890d-649d-427b-b5cf-ee4cc0267d0b.jpg'),(50,78,'240628','강아지.jpg','894253d9-9f56-49ab-a2a8-8b19f1eacbee.jpg'),(51,79,'240628','강아지.jpg','00400593-c33c-44f7-b426-ff7793e95af4.jpg'),(52,80,'240628','강아지.jpg','a2710c56-5e94-43f4-88fd-36fe11182b80.jpg'),(53,81,'240628','강아지.jpg','9a056bfc-eb92-493b-807c-c0017bc5b856.jpg'),(54,82,'240628','강아지.jpg','d9081f96-43e3-46b3-a273-e0a6205f913e.jpg'),(55,83,'240628','강아지.jpg','3e750d3e-956e-4c1e-8470-1998c58dcffd.jpg'),(56,84,'240628','강아지.jpg','9a90bbb9-b0cf-46f9-9de7-bcc8dc301228.jpg'),(57,85,'240628','강아지.jpg','c2e6017c-30f5-48ca-8933-af024b128d2a.jpg'),(58,86,'240628','강아지.jpg','aba86f73-6e28-4d6f-b6e0-9ca1372c62ec.jpg'),(59,87,'240628','강아지.jpg','f254b5e5-b504-4f0d-b363-017d7c327643.jpg'),(60,88,'240702','요리왕비룡4.jpg','4c494ed4-62cc-4b07-b6ee-d49a95a927c8.jpg'),(61,89,'240702','요리왕비룡4.jpg','3607ceb9-a551-4be3-8aa1-f4304b3bbb40.jpg'),(62,90,'240702','요리왕비룡4.jpg','48dde9d2-49af-49f8-9e04-c78d951cbec3.jpg'),(63,91,'240702','요리왕비룡4.jpg','c6fd2195-8b99-4bf2-a39d-8bec03555276.jpg'),(64,92,'240702','요리왕비룡4.jpg','b379922a-a262-42d6-a29d-170309be0c97.jpg'),(65,93,'240702','요리왕비룡4.jpg','bcaa5967-914d-41ae-a876-985565634b13.jpg'),(66,94,'240702','요리왕비룡4.jpg','85c30295-c740-432f-9961-4bb1bf9353b2.jpg'),(67,95,'240702','요리왕비룡4.jpg','5a2bd3b6-97e3-4b2f-af53-b7288584b1f3.jpg'),(68,96,'240702','요리왕비룡4.jpg','1c4082ec-cc43-4a9e-89d2-fbac51096622.jpg');
/*!40000 ALTER TABLE `plan_file` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-15 20:25:10
